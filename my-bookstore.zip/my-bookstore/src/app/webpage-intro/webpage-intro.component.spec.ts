import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WebpageIntroComponent } from './webpage-intro.component';

describe('WebpageIntroComponent', () => {
  let component: WebpageIntroComponent;
  let fixture: ComponentFixture<WebpageIntroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WebpageIntroComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WebpageIntroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
