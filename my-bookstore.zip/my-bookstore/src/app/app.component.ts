import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { WebpageIntroComponent } from './webpage-intro/webpage-intro.component'
import { FeaturedBooksComponent } from './featured-books/featured-books.component'
import { AboutUsComponent } from './about-us/about-us.component'
import { BooksComponent } from './books/books.component'
import { AddBooksComponent } from './add-books/add-books.component'
import { CustomerReviewsComponent } from './customer-reviews/customer-reviews.component'
import { ContactUsComponent } from './contact-us/contact-us.component'
import { FooterComponent } from './footer/footer.component'

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    HeaderComponent,
    WebpageIntroComponent,
    FeaturedBooksComponent,
    AboutUsComponent,
    BooksComponent,
    AddBooksComponent,
    CustomerReviewsComponent,
    ContactUsComponent,
    FooterComponent
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

}
