import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookService } from '../book.service';

interface Book {
  id?: number;
  title: string;
  author: string;
  price: string;
  description: string;
  imageUrl: string;
}

@Component({
  selector: 'app-books',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './books.component.html',
  styleUrl: './books.component.css'
})
export class BooksComponent {
  books: Book[] = [];
  booksLoaded = 0;
  booksPerLoad = 6;

  constructor(private bookService: BookService) { }

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.bookService.getBooks().subscribe((books: Book[]) => {
      this.books = books.slice(0, this.booksPerLoad);
      this.booksLoaded = this.books.length;
    });
  }

  loadMoreBooks(): void {
    this.booksLoaded += this.booksPerLoad;
    this.bookService.getBooks().subscribe((books: Book[]) => {
      this.books = books.slice(0, this.booksLoaded);
    });
  }

  deleteBook(id: number | undefined): void {
    if (id) {
      this.bookService.deleteBook(id).subscribe(() => {
        this.books = this.books.filter(book => book.id !== id);
      });
    }
  }
}
