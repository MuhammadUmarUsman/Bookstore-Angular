import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-reviews',
  standalone: true,
  imports: [],
  templateUrl: './customer-reviews.component.html',
  styleUrl: './customer-reviews.component.css'
})
export class CustomerReviewsComponent {

}
