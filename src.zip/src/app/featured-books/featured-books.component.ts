import { Component } from '@angular/core';

@Component({
  selector: 'app-featured-books',
  standalone: true,
  imports: [],
  templateUrl: './featured-books.component.html',
  styleUrl: './featured-books.component.css'
})
export class FeaturedBooksComponent {

}
