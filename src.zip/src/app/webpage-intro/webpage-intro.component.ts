import { Component } from '@angular/core';

@Component({
  selector: 'app-webpage-intro',
  standalone: true,
  imports: [],
  templateUrl: './webpage-intro.component.html',
  styleUrl: './webpage-intro.component.css'
})
export class WebpageIntroComponent {

}
