import { Component } from '@angular/core';
import { BookService } from '../book.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

interface Book {
  id?: number;
  title: string;
  author: string;
  price: string;
  description: string;
  imageUrl: string;
}

@Component({
  selector: 'app-add-books',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './add-books.component.html',
  styleUrl: './add-books.component.css'
})
export class AddBooksComponent {
  newBook: Book = {
    title: '',
    author: '',
    price: '',
    description: '',
    imageUrl: ''
  };
  errorMessage = '';
  successMessage = '';

  constructor(private bookService: BookService) { }

  addBook(): void {
    this.bookService.addBook(this.newBook).subscribe(
      (book: Book) => {
        this.successMessage = 'Book added successfully!';
        this.errorMessage = '';
        this.newBook = {
          title: '',
          author: '',
          price: '',
          description: '',
          imageUrl: ''
        };
      },
      (error: any) => {
        this.errorMessage = 'Error adding book. Please try again.';
        this.successMessage = '';
      }
    );
  }
}
